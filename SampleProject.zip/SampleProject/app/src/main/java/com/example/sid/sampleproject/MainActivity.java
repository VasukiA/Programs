package com.example.sid.sampleproject;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sid.sampleproject.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    static final String TAG = "Please Enter All the fields";
    private String mLabel1, mLabel2, mLabel3, mLabel4, mLabel5, mLabel6;
    private ActivityMainBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        mBinding.setSample(this);
        mBinding.activityMainSubmitBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        SampleLabel labels = new SampleLabel();
        mLabel1 = mBinding.activityMainEt1.getText().toString();
        mLabel2 = mBinding.activityMainEt2.getText().toString();
        mLabel3 = mBinding.activityMainEt3.getText().toString();
        mLabel4 = mBinding.activityMainEt4.getText().toString();
        mLabel5 = mBinding.activityMainEt5.getText().toString();
        mLabel6 = mBinding.activityMainEt6.getText().toString();
        if (!mLabel1.isEmpty() && !mLabel2.isEmpty() && !mLabel3.isEmpty() && !mLabel4.isEmpty() && !mLabel5.isEmpty() && !mLabel6.isEmpty()) {
            labels.setLabel1(mLabel1);
            labels.setLabel2(mLabel2);
            labels.setLabel3(mLabel3);
            labels.setLabel4(mLabel4);
            labels.setLabel5(mLabel5);
            labels.setLabel6(mLabel6);
            Toast.makeText(this, getResources().getString(R.string.success), Toast.LENGTH_LONG).show();
        } else {
            if (mLabel1.isEmpty()) {
                openKeyboard(mBinding.activityMainEt1);
            } else if (mLabel2.isEmpty()) {
                openKeyboard(mBinding.activityMainEt2);
            } else if (mLabel3.isEmpty()) {
                openKeyboard(mBinding.activityMainEt3);
            } else if (mLabel4.isEmpty()) {
                openKeyboard(mBinding.activityMainEt4);
            } else if (mLabel5.isEmpty()) {
                openKeyboard(mBinding.activityMainEt5);
            } else {
                openKeyboard(mBinding.activityMainEt6);
            }
            Toast.makeText(this, TAG, Toast.LENGTH_LONG).show();
        }
    }

    public void openKeyboard(EditText editTextName) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.toggleSoftInputFromWindow(editTextName.getApplicationWindowToken(), InputMethodManager.SHOW_FORCED, 0);
        editTextName.requestFocus();
    }
}
